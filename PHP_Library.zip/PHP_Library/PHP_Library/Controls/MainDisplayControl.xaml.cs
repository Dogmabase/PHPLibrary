﻿using System.Windows.Controls;

namespace PHP_Library.Controls
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class MainDisplayControl : UserControl
    {
        public MainDisplayControl()
        {
            InitializeComponent();
        }
    }
}
